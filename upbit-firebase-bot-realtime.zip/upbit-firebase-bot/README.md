# Upbit Auto-Trader (Firebase + React)

⚠️ **주의/면책**
- 이 프로젝트는 예시 코드입니다. 손실 가능성이 매우 큽니다. 실거래는 전적으로 본인 책임입니다.
- 업비트 Open API 이용약관/제한을 반드시 준수하세요. (요청 제한, 권한, IP 차단 등)
- Upbit Docs: https://docs.upbit.com/kr/

- API Key(Access/Secret)는 **절대 웹(프론트)로 노출하면 안 됩니다.** 이 프로젝트는 Cloud Functions Secret으로만 보관하도록 구성했습니다.
- Firebase schedule functions: https://firebase.google.com/docs/functions/schedule-functions
- Upbit authentication: https://docs.upbit.com/kr/reference/auth


## 기능 (MVP)
- 웹 대시보드(React + Firebase Hosting)
  - 봇 **시작/중지**
  - **총 자본**, **총 실현 손익**, **최근 주문별 손익(최근 20건)** 표시
- Cloud Functions (예약 실행)
  - 매 1분마다 동작(스캔/포지션 관리) 
  - 동시보유 1개
  - 익절(+3%) / 손절(-6%) 닿으면 전량 청산
  - 일일 손실이 **당일 시작 자본 대비 -30% 이하**면 자동 중지
  - 주문당 최대 400,000 KRW
  - Paper Mode(모의매매) 지원

## 폴더 구조
- `functions/` : Firebase Cloud Functions (TypeScript)
- `web/` : React (Vite) 대시보드
- `firestore.rules` : Firestore 보안 규칙
- `firebase.json` : Hosting/Functions 설정

---

# 1) 사전 준비
1. Node.js 20+ 설치
2. Firebase CLI 설치
   ```bash
   npm i -g firebase-tools
   firebase login
   ```
✅ **중요: 배포(프로덕션) Cloud Functions 사용에는 Blaze(결제 계정) 전환이 필요합니다.**
Firebase 공식 문서에서도 Functions 배포 단계에서 Blaze 업그레이드를 안내합니다. (Spark 무료 요금제는 대시보드(Hosting/Firestore) 정도만 운영 가능)

3. Firebase Console에서 프로젝트 생성
   - Firestore Database 생성(Native)
   - Authentication > Sign-in method에서 Email/Password 활성화
   - 사용자(본인 이메일) 1명 생성(나중에 UID를 rules에 넣을 것)

---

# 2) Firebase 프로젝트 연결
루트 폴더에서:
```bash
firebase use --add
# 또는 firebase init 후 기존 프로젝트 선택
```

`./.firebaserc.example`를 복사해서 `.firebaserc`로 바꾸고 프로젝트 id를 넣어도 됩니다.

---

# 3) Firestore 보안 규칙(중요)
이 프로젝트는 웹에서 `config/global.enabled` 를 토글합니다.
그래서 **로그인한 사용자 중 “나만” 쓰기 가능**하게 제한해야 합니다.

1) Firebase Console > Authentication에서 내 UID 확인  
2) `firestore.rules`에서 `ALLOWED_UIDS` 배열에 UID 추가  
3) 배포:
```bash
firebase deploy --only firestore:rules
```

---

# 4) 업비트 API Key 등록(Functions Secret)
업비트 API Key 권한은 최소로:
- 잔고조회
- 주문조회
- 주문하기

Secret 등록:
```bash
cd functions
npm i
firebase functions:secrets:set UPBIT_ACCESS_KEY
firebase functions:secrets:set UPBIT_SECRET_KEY
firebase functions:secrets:set BOT_INTERNAL_TOKEN
```

> 업비트 인증은 JWT 기반이며, 파라미터가 있으면 query_hash(SHA512)를 포함합니다. 

---

# 5) Functions 배포
```bash
firebase deploy --only functions
```

예약 함수는 `onSchedule("* * * * *")` 로 매 1분 실행됩니다. 

---

# 6) Web(React) 설정 & 배포
1) Firebase 웹 앱 추가(콘솔) → SDK 설정 값을 복사
2) `web/.env.example` → `web/.env` 로 복사 후 값 채우기
3) 빌드 & Hosting 배포:
```bash
cd web
npm i
npm run build
cd ..
firebase deploy --only hosting
```

---

# 7) 첫 실행(권장: Paper Mode)
Firestore 문서 `config/global`에서
- `paperMode: true` 로 시작 권장
- 대시보드에서 `Start` 누르면 1분마다 동작합니다.

---

# 8) 전략 파라미터 튜닝
- `functions/src/strategy.ts` 참고
  - 후보군: 24h 거래대금 상위 N개 → (옵션) 4h 거래대금 랭킹
  - 3시간 최저가: 1분봉 180개 min(low)
  - RSI(14), Stoch RSI, 200EMA(상위TF), 1분 거래량 증가

업비트 캔들 API는 1/3/5/10/15/30/60/240분만 지원하며, 체결이 없는 시간대는 캔들이 생성되지 않을 수 있습니다.
- Minute candles: https://docs.upbit.com/kr/reference/list-candles-minutes
 

---

## Troubleshooting
- 401/권한 오류: 업비트 API Key 권한 확인
  - Order: https://docs.upbit.com/kr/reference/new-order
  - Get order: https://docs.upbit.com/kr/reference/get-order
 
- 429(요청 제한): 후보 수/동시 호출 수 줄이기
  - Rate limits (candles): https://global-docs.upbit.com/reference/list-candles-minutes
 

## 5) (선택) TP/SL 실시간 청산 (Cloud Run WebSocket 모니터)
기본 구성은 **1분마다** Functions가 TP/SL을 체크해서 청산합니다.  
더 빠르게(수초 단위) 청산하려면 `realtime/` Cloud Run 서비스를 추가로 배포할 수 있습니다.

- Cloud Run 서비스는 Upbit WebSocket으로 현재 보유 코인의 틱을 구독합니다.
- TP/SL 도달 시 즉시 `closeNow`(HTTPS Function)를 호출해 청산합니다.

### 배포 순서
1) 먼저 Functions 배포 후 `closeNow` URL 확인  
   URL 형식:
   `https://asia-northeast3-<PROJECT_ID>.cloudfunctions.net/closeNow`

2) Cloud Run 배포  
   `realtime/README.md` 참고

⚠️ Cloud Run은 Google Cloud Billing(결제 계정)이 필요합니다.
