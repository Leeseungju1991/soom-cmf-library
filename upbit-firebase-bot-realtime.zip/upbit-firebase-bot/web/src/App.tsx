import React, { useEffect, useMemo, useState } from "react";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { auth, db } from "./firebase";
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc
} from "firebase/firestore";
import { fmtDate, fmtKrw, fmtPct } from "./lib/format";
import { seoulDateId } from "./lib/time";

type Summary = {
  initialEquityKrw?: number;
  currentEquityKrw?: number;
  totalRealizedPnlKrw?: number;
  totalFeesKrw?: number;
  totalTrades?: number;
  winTrades?: number;
  lossTrades?: number;
};

type Runtime = {
  botState: "RUNNING" | "PAUSED" | "ERROR";
  pauseReason?: string;
  lastRunAt?: any;
  lastError?: string;
};

type Position = {
  isOpen: boolean;
  market?: string;
  entryPrice?: number;
  qty?: number;
  entryKrw?: number;
  tpPrice?: number;
  slPrice?: number;
  lastPrice?: number;
  unrealizedPnlKrw?: number;
  unrealizedPnlPct?: number;
  entryAt?: any;
  closing?: boolean;
  closingBy?: string;
};

type Trade = {
  market: string;
  entryAt: any;
  exitAt: any;
  pnlKrw: number;
  pnlPct: number;
  exitReason: string;
  entryKrw: number;
  exitKrw: number;
  feesKrw: number;
};

type Config = {
  enabled: boolean;
  paperMode: boolean;
  maxOrderKrw: number;
  takeProfitPct: number;
  stopLossPct: number;
  dailyLossLimitPct: number;
};

type DailyStats = {
  dayStartEquityKrw?: number;
  realizedPnlKrw?: number;
  feesKrw?: number;
  lossLimitTriggered?: boolean;
  updatedAt?: any;
};

export default function App() {
  const [user, setUser] = useState<any>(null);

  // login form
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [loginErr, setLoginErr] = useState<string>("");

  // data
  const [summary, setSummary] = useState<Summary>({});
  const [runtime, setRuntime] = useState<Runtime>({ botState: "PAUSED" });
  const [position, setPosition] = useState<Position>({ isOpen: false });
  const [config, setConfig] = useState<Config | null>(null);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [daily, setDaily] = useState<DailyStats>({});

  useEffect(() => {
    return onAuthStateChanged(auth, (u) => setUser(u));
  }, []);

  useEffect(() => {
    if (!user) return;

    const unsub1 = onSnapshot(doc(db, "stats/summary"), (snap) => setSummary((snap.data() || {}) as Summary));
    const unsub2 = onSnapshot(doc(db, "state/runtime"), (snap) => setRuntime((snap.data() || { botState: "PAUSED" }) as Runtime));
    const unsub3 = onSnapshot(doc(db, "state/position"), (snap) => setPosition((snap.data() || { isOpen: false }) as Position));
    const unsub4 = onSnapshot(doc(db, "config/global"), (snap) => setConfig((snap.data() || null) as Config));
    const dayId = seoulDateId();
    const unsubDaily = onSnapshot(doc(db, `stats_daily/${dayId}`), (snap) => setDaily((snap.data() || {}) as DailyStats));

    const q = query(collection(db, "trades"), orderBy("exitAt", "desc"), limit(20));
    const unsub5 = onSnapshot(q, (snap) => {
      const rows: Trade[] = [];
      snap.forEach((d) => rows.push(d.data() as Trade));
      setTrades(rows);
    });

    // ensure config exists (first time)
    setDoc(doc(db, "config/global"), { enabled: false }, { merge: true }).catch(() => {});

    return () => {
      unsub1(); unsub2(); unsub3(); unsub4(); unsubDaily(); unsub5();
    };
  }, [user]);

  

const dailyInfo = useMemo(() => {
  const equity = summary.currentEquityKrw ?? 0;
  const dayStart = daily.dayStartEquityKrw ?? equity;
  const lossLimit = config?.dailyLossLimitPct ?? 0.30;
  const drawdownPct = dayStart > 0 ? (equity - dayStart) / dayStart : 0;
  const dd = Math.min(0, drawdownPct);
  const progress = lossLimit > 0 ? Math.min(1, Math.max(0, (-dd) / lossLimit)) : 0;
  return {
    dayId: seoulDateId(),
    dayStart,
    equity,
    realizedPnl: daily.realizedPnlKrw ?? 0,
    fees: daily.feesKrw ?? 0,
    drawdownPct,
    lossLimit,
    progress,
    triggered: !!daily.lossLimitTriggered
  };
}, [summary.currentEquityKrw, daily.dayStartEquityKrw, daily.realizedPnlKrw, daily.feesKrw, daily.lossLimitTriggered, config?.dailyLossLimitPct]);const badge = useMemo(() => {
    const s = runtime.botState;
    if (s === "RUNNING") return { cls: "ok", label: "RUNNING" };
    if (s === "ERROR") return { cls: "err", label: "ERROR" };
    return { cls: "warn", label: "PAUSED" };
  }, [runtime.botState]);

  async function doLogin() {
    setLoginErr("");
    try {
      await signInWithEmailAndPassword(auth, email, pw);
    } catch (e: any) {
      setLoginErr(e?.message || "Login failed");
    }
  }

  async function toggleEnabled(next: boolean) {
    await updateDoc(doc(db, "config/global"), { enabled: next });
  }

  async function togglePaper(next: boolean) {
    await updateDoc(doc(db, "config/global"), { paperMode: next });
  }

  if (!user) {
    return (
      <div className="container">
        <div className="card" style={{ maxWidth: 420, margin: "40px auto" }}>
          <div className="h1">Upbit Bot Dashboard</div>
          <div className="small">Firebase Auth(Email/Password)로 로그인하세요.</div>
          <div style={{ height: 12 }} />
          <input className="input" placeholder="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <div style={{ height: 10 }} />
          <input className="input" placeholder="password" type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          <div style={{ height: 12 }} />
          <button className="btn primary" onClick={doLogin} style={{ width: "100%" }}>Login</button>
          {loginErr && <div className="small" style={{ color: "#b42318", marginTop: 10 }}>{loginErr}</div>}
          <div style={{ height: 10 }} />
          <div className="small">
            ※ Firestore rules에서 본인 UID만 write 가능하게 설정하세요.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="topbar">
        <div>
          <div className="h1">Upbit Bot Dashboard</div>
          <div className={`badge ${badge.cls}`}>
            <span>State:</span>
            <b>{badge.label}</b>
            {runtime.pauseReason ? <span className="small">({runtime.pauseReason})</span> : null}
          </div>
          <div className="small">Last run: {fmtDate(runtime.lastRunAt)}</div>
          {runtime.lastError ? <div className="small" style={{ color: "#b42318" }}>Error: {runtime.lastError}</div> : null}
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button className="btn" onClick={() => signOut(auth)}>Logout</button>
        </div>
      </div>

      <div className="row">
        <div className="card col">
          <div className="h2">Controls</div>
          <div className="kv"><div className="k">Enabled</div><div className="v">{config?.enabled ? "ON" : "OFF"}</div></div>
          <div style={{ height: 10 }} />
          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn primary" disabled={!!config?.enabled} onClick={() => toggleEnabled(true)}>Start</button>
            <button className="btn danger" disabled={!config?.enabled} onClick={() => toggleEnabled(false)}>Stop</button>
          </div>

          <div style={{ height: 14 }} />
          <div className="kv"><div className="k">Paper mode</div><div className="v">{config?.paperMode ? "ON" : "OFF"}</div></div>
          <div style={{ height: 12 }} />
          <div className="kv"><div className="k">Max order</div><div className="v">{fmtKrw(config?.maxOrderKrw ?? null)}</div></div>
          <div className="kv"><div className="k">TP / SL</div><div className="v">{fmtPct(config?.takeProfitPct ?? null)} / {fmtPct(config?.stopLossPct ?? null)}</div></div>
          <div className="kv"><div className="k">Daily loss limit</div><div className="v">{fmtPct(config?.dailyLossLimitPct ?? null)}</div></div>
          <div style={{ height: 10 }} />
          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn" onClick={() => togglePaper(true)}>Paper ON</button>
            <button className="btn" onClick={() => togglePaper(false)}>Paper OFF</button>
          </div>

          <div style={{ height: 12 }} />
          <div className="small">
            Paper OFF(실거래)는 Functions Secrets에 업비트 키가 설정되어 있어야 합니다.
          </div>
        </div>

        <div className="card col">
          <div className="h2">Summary</div>
          <div className="kv"><div className="k">Total capital</div><div className="v">{fmtKrw(summary.currentEquityKrw ?? null)}</div></div>
          <div className="kv"><div className="k">Total realized PnL</div><div className="v">{fmtKrw(summary.totalRealizedPnlKrw ?? 0)}</div></div>
          <div className="kv"><div className="k">Total fees</div><div className="v">{fmtKrw(summary.totalFeesKrw ?? 0)}</div></div>
          <div className="kv"><div className="k">Trades</div><div className="v">{summary.totalTrades ?? 0}</div></div>
          <div className="kv"><div className="k">Win / Loss</div><div className="v">{summary.winTrades ?? 0} / {summary.lossTrades ?? 0}</div></div>

<div style={{ height: 14 }} />
<div className="h2">Today (KST)</div>
<div className="small">{dailyInfo.dayId}</div>
<div className="kv"><div className="k">Day start equity</div><div className="v">{fmtKrw(dailyInfo.dayStart)}</div></div>
<div className="kv"><div className="k">Realized PnL (today)</div><div className="v">{fmtKrw(dailyInfo.realizedPnl)}</div></div>
<div className="kv"><div className="k">Fees (today)</div><div className="v">{fmtKrw(dailyInfo.fees)}</div></div>
<div className="kv"><div className="k">Drawdown</div><div className="v">{fmtPct(dailyInfo.drawdownPct)}</div></div>

<div style={{ height: 8 }} />
<div className="small">Daily loss limit progress</div>
<div style={{ height: 10, background: "#f2f4f7", borderRadius: 999, overflow: "hidden" }}>
  <div style={{ height: 10, width: `${Math.round(dailyInfo.progress * 100)}%`, background: dailyInfo.triggered ? "#b42318" : "#1570ef" }} />
</div>
<div className="small" style={{ marginTop: 6 }}>
  {Math.round(dailyInfo.progress * 100)}% of limit ({fmtPct(dailyInfo.lossLimit)}).
  {dailyInfo.triggered ? <b style={{ marginLeft: 8, color: "#b42318" }}>Triggered</b> : null}
</div>
        </div>

        <div className="card col">
          <div className="h2">Current Position</div>
          {position.isOpen ? (
            <>
              <div className="kv"><div className="k">Market</div><div className="v">{position.market}</div></div>
              {position.closing ? <div className="small" style={{ color: "#b42318" }}>Closing… ({position.closingBy || "server"})</div> : null}
              <div className="kv"><div className="k">Entry price</div><div className="v">{position.entryPrice?.toLocaleString() ?? "-"}</div></div>
              <div className="kv"><div className="k">Qty</div><div className="v">{position.qty?.toFixed(8) ?? "-"}</div></div>
              <div className="kv"><div className="k">TP / SL</div><div className="v">{position.tpPrice?.toLocaleString() ?? "-"} / {position.slPrice?.toLocaleString() ?? "-"}</div></div>
              <div className="kv"><div className="k">Last price</div><div className="v">{position.lastPrice?.toLocaleString() ?? "-"}</div></div>
              <div className="kv"><div className="k">Unrealized PnL</div><div className="v">{fmtKrw(position.unrealizedPnlKrw ?? null)} ({fmtPct(position.unrealizedPnlPct ?? null)})</div></div>
              <div className="small">Entry at: {fmtDate(position.entryAt)}</div>
            </>
          ) : (
            <div className="small">No open position</div>
          )}
        </div>
      </div>

      <div style={{ height: 14 }} />

      <div className="card">
        <div className="h2">Recent Trades (last 20)</div>
        <table className="table">
          <thead>
            <tr>
              <th>Market</th>
              <th>Exit time</th>
              <th>Reason</th>
              <th>PnL</th>
              <th>Fees</th>
            </tr>
          </thead>
          <tbody>
            {trades.map((t, idx) => (
              <tr key={idx}>
                <td>{t.market}</td>
                <td>{fmtDate(t.exitAt)}</td>
                <td>{t.exitReason}</td>
                <td style={{ fontWeight: 700, color: t.pnlKrw >= 0 ? "#067647" : "#b42318" }}>
                  {fmtKrw(t.pnlKrw)} ({fmtPct(t.pnlPct)})
                </td>
                <td>{fmtKrw(t.feesKrw)}</td>
              </tr>
            ))}
            {trades.length === 0 ? (
              <tr><td colSpan={5} className="small">No trades yet</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
