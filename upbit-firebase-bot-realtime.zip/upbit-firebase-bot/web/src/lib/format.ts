export function fmtKrw(n?: number | null): string {
  if (n === undefined || n === null || Number.isNaN(n)) return "-";
  return new Intl.NumberFormat("ko-KR", { style: "currency", currency: "KRW", maximumFractionDigits: 0 }).format(n);
}

export function fmtPct(n?: number | null): string {
  if (n === undefined || n === null || Number.isNaN(n)) return "-";
  return `${(n * 100).toFixed(2)}%`;
}

export function fmtDate(d: any): string {
  if (!d) return "-";
  // Firestore Timestamp { seconds, nanoseconds }
  const ms = d.toMillis ? d.toMillis() : (d.seconds ? d.seconds * 1000 : Date.parse(d));
  if (!Number.isFinite(ms)) return "-";
  return new Date(ms).toLocaleString("ko-KR");
}
