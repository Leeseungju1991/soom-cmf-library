import express from "express";
import admin from "firebase-admin";
import WebSocket from "ws";

type Position = {
  isOpen: boolean;
  market?: string;
  entryPrice?: number;
  tpPrice?: number;
  slPrice?: number;
  closing?: boolean;
  entryAt?: any;
};

const CLOSE_NOW_URL = process.env.CLOSE_NOW_URL || "";
const BOT_INTERNAL_TOKEN = process.env.BOT_INTERNAL_TOKEN || "";

if (!CLOSE_NOW_URL) throw new Error("Missing env CLOSE_NOW_URL");
if (!BOT_INTERNAL_TOKEN) throw new Error("Missing env BOT_INTERNAL_TOKEN");

// Firestore
admin.initializeApp();
const db = admin.firestore();

let current: Position = { isOpen: false };
let lastPositionKey = "";
let ws: WebSocket | null = null;
let wsMarket = "";
let firedKey = "";
let isClosingCallInFlight = false;

function makePositionKey(p: Position): string {
  if (!p.isOpen) return "";
  const ts = p.entryAt?.seconds ?? p.entryAt?._seconds ?? p.entryAt?.toMillis?.() ?? "";
  return `${p.market || ""}:${ts}`;
}

function connectWs(market: string) {
  if (!market) return;

  if (ws && ws.readyState === WebSocket.OPEN && wsMarket === market) return;

  // reset
  try { ws?.close(); } catch {}
  ws = null;
  wsMarket = market;

  const url = "wss://api.upbit.com/websocket/v1";
  const socket = new WebSocket(url, { perMessageDeflate: false });
  ws = socket;

  socket.on("open", () => {
    const msg = [
      { ticket: "upbit-bot" },
      { type: "ticker", codes: [market] }
    ];
    socket.send(JSON.stringify(msg));
    console.log("WS subscribed:", market);
  });

  socket.on("message", (data) => {
    try {
      const text = Buffer.isBuffer(data) ? data.toString("utf8") : data.toString();
      const obj = JSON.parse(text);
      const price = Number(obj.trade_price);
      if (!Number.isFinite(price)) return;

      // Only when still same position
      const key = makePositionKey(current);
      if (!key || key !== lastPositionKey) return;
      if (!current.isOpen || current.closing) return;

      if (firedKey === key) return;

      if (current.tpPrice && price >= current.tpPrice) {
        triggerClose("TAKE_PROFIT", price).catch(console.error);
      } else if (current.slPrice && price <= current.slPrice) {
        triggerClose("STOP_LOSS", price).catch(console.error);
      }
    } catch (e) {
      // ignore parse errors
    }
  });

  socket.on("close", () => {
    console.log("WS closed. Reconnecting in 2s...");
    setTimeout(() => {
      if (current.isOpen && current.market) connectWs(current.market);
    }, 2000);
  });

  socket.on("error", (err) => {
    console.log("WS error:", err?.message || err);
    try { socket.close(); } catch {}
  });
}

async function triggerClose(reason: "TAKE_PROFIT" | "STOP_LOSS", lastPrice: number) {
  const key = makePositionKey(current);
  if (!key) return;
  if (firedKey === key) return;
  if (isClosingCallInFlight) return;

  isClosingCallInFlight = true;
  try {
    firedKey = key;
    console.log("Trigger close:", reason, "market:", current.market, "lastPrice:", lastPrice);

    const resp = await fetch(CLOSE_NOW_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${BOT_INTERNAL_TOKEN}`
      },
      body: JSON.stringify({ reason, market: current.market, lastPrice })
    });

    if (!resp.ok) {
      const txt = await resp.text();
      console.log("closeNow failed:", resp.status, txt);
      // If failed, allow retry
      firedKey = "";
    } else {
      console.log("closeNow OK");
    }
  } finally {
    isClosingCallInFlight = false;
  }
}

// Watch position doc
db.doc("state/position").onSnapshot((snap) => {
  const p = (snap.data() || { isOpen: false }) as Position;
  current = p;
  const key = makePositionKey(p);

  if (!p.isOpen) {
    lastPositionKey = "";
    firedKey = "";
    wsMarket = "";
    try { ws?.close(); } catch {}
    ws = null;
    return;
  }

  // new position
  if (key && key !== lastPositionKey) {
    lastPositionKey = key;
    firedKey = "";
  }

  if (p.market) connectWs(p.market);
}, (err) => {
  console.error("position watch error:", err);
});

// minimal HTTP server (health check)
const app = express();
app.get("/", (_req, res) => {
  res.json({ ok: true, watching: current.isOpen ? current.market : null });
});
app.get("/healthz", (_req, res) => res.send("ok"));
const port = Number(process.env.PORT || "8080");
app.listen(port, () => console.log("Realtime monitor listening on", port));
