# Realtime monitor (Cloud Run)

This service:
- Watches `state/position` in Firestore
- Subscribes to Upbit WebSocket ticker for the current position market
- When TP/SL is hit, it calls the Firebase HTTPS function `closeNow`

## Required env vars (Cloud Run)

- `CLOSE_NOW_URL` : e.g. `https://asia-northeast3-<PROJECT_ID>.cloudfunctions.net/closeNow`
- `BOT_INTERNAL_TOKEN` : must match the Firebase Functions secret `BOT_INTERNAL_TOKEN`

## Deploy (example)

```bash
gcloud auth login
gcloud config set project <PROJECT_ID>

gcloud run deploy upbit-realtime-monitor \
  --source . \
  --region asia-northeast3 \
  --min-instances=1 --max-instances=1 \
  --memory 256Mi --cpu 1 \
  --no-cpu-throttling \
  --set-env-vars CLOSE_NOW_URL="https://asia-northeast3-<PROJECT_ID>.cloudfunctions.net/closeNow",BOT_INTERNAL_TOKEN="<TOKEN>" \
  --allow-unauthenticated
```

> Note: Cloud Run requires a billing account. For a 24h test run, you often stay within Cloud Run's monthly free tier, but for 24/7 it can incur cost.
