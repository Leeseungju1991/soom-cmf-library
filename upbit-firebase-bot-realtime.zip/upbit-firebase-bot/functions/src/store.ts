import admin from "firebase-admin";
import { DailyStats, GlobalConfig, PositionState, RuntimeState, SummaryStats } from "./types";
import { seoulDateId } from "./time";

export const db = admin.firestore();

export const refs = {
  config: () => db.doc("config/global"),
  runtime: () => db.doc("state/runtime"),
  position: () => db.doc("state/position"),
  lock: () => db.doc("state/lock"),
  summary: () => db.doc("stats/summary"),
  daily: (dayId?: string) => db.doc(`stats_daily/${dayId ?? seoulDateId()}`),
  trade: (tradeId: string) => db.collection("trades").doc(tradeId),
  marketsCache: () => db.doc("cache/markets")
};

export async function getConfig(): Promise<GlobalConfig> {
  const snap = await refs.config().get();
  if (!snap.exists) {
    const init: GlobalConfig = {
      enabled: false,
      paperMode: true,
      maxOrderKrw: 400000,
      takeProfitPct: 0.03,
      stopLossPct: -0.06,
      dailyLossLimitPct: 0.30,
      cooldownMinutes: 5,
      candidateCount: 12,
      prefilterCount: 30,
      topMarkets: "KRW",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await refs.config().set(init);
    return init;
  }
  return snap.data() as GlobalConfig;
}

export async function setRuntime(partial: Partial<RuntimeState>) {
  await refs.runtime().set(
    {
      botState: "PAUSED",
      pauseReason: "",
      ...partial,
      lastRunAt: admin.firestore.FieldValue.serverTimestamp()
    },
    { merge: true }
  );
}

export async function getRuntime(): Promise<RuntimeState> {
  const snap = await refs.runtime().get();
  if (!snap.exists) {
    const init: RuntimeState = { botState: "PAUSED", pauseReason: "" };
    await refs.runtime().set({ ...init, lastRunAt: admin.firestore.FieldValue.serverTimestamp() });
    return init;
  }
  return snap.data() as RuntimeState;
}

export async function getPosition(): Promise<PositionState> {
  const snap = await refs.position().get();
  if (!snap.exists) {
    const init: PositionState = { isOpen: false };
    await refs.position().set(init);
    return init;
  }
  return snap.data() as PositionState;
}

export async function setPosition(partial: Partial<PositionState>) {
  await refs.position().set(
    {
      ...partial,
      lastUpdatedAt: admin.firestore.FieldValue.serverTimestamp()
    },
    { merge: true }
  );
}

export async function clearPosition() {
  await refs.position().set({ isOpen: false }, { merge: false });
}

export async function getSummary(): Promise<SummaryStats> {
  const snap = await refs.summary().get();
  if (!snap.exists) {
    const init: SummaryStats = {
      totalRealizedPnlKrw: 0,
      totalFeesKrw: 0,
      totalTrades: 0,
      winTrades: 0,
      lossTrades: 0,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await refs.summary().set(init);
    return init;
  }
  return snap.data() as SummaryStats;
}

export async function setSummary(partial: Partial<SummaryStats>) {
  await refs.summary().set({ ...partial, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
}

export async function getOrInitDaily(dayId: string): Promise<DailyStats> {
  const ref = refs.daily(dayId);
  const snap = await ref.get();
  if (!snap.exists) {
    const init: DailyStats = {
      realizedPnlKrw: 0,
      feesKrw: 0,
      lossLimitTriggered: false,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await ref.set(init);
    return init;
  }
  return snap.data() as DailyStats;
}

export async function updateDaily(dayId: string, partial: Partial<DailyStats>) {
  await refs.daily(dayId).set({ ...partial, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
}

export async function acquireCloseLock(actor: string): Promise<boolean> {
  const posRef = refs.position();
  try {
    const ok = await db.runTransaction(async (tx) => {
      const snap = await tx.get(posRef);
      const pos = (snap.data() || {}) as any;
      if (!pos.isOpen) return false;
      if (pos.closing) return false;
      tx.set(posRef, {
        closing: true,
        closingBy: actor,
        closingAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
      return true;
    });
    return ok as boolean;
  } catch (e) {
    console.warn("acquireCloseLock failed", e);
    return false;
  }
}

export async function withLock<T>(fn: () => Promise<T>, ttlMs = 110_000): Promise<T | null> {
  const lockRef = refs.lock();
  const now = Date.now();
  try {
    await db.runTransaction(async (tx) => {
      const snap = await tx.get(lockRef);
      const lockedUntil = snap.exists ? (snap.data()?.lockedUntilMs as number | undefined) : undefined;
      if (lockedUntil && lockedUntil > now) {
        throw new Error("LOCKED");
      }
      tx.set(lockRef, { lockedUntilMs: now + ttlMs, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    });
  } catch (e: any) {
    if (String(e?.message || "").includes("LOCKED")) return null;
    throw e;
  }

  try {
    return await fn();
  } finally {
    // best-effort unlock
    await lockRef.set({ lockedUntilMs: 0, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  }
}
