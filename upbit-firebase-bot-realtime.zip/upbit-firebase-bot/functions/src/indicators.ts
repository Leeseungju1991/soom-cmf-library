export function ema(values: number[], period: number): number[] {
  if (values.length === 0) return [];
  const k = 2 / (period + 1);
  const out: number[] = [];
  let prev = values[0];
  out.push(prev);
  for (let i = 1; i < values.length; i++) {
    const v = values[i];
    const next = v * k + prev * (1 - k);
    out.push(next);
    prev = next;
  }
  return out;
}

export function rsi(closes: number[], period = 14): number[] {
  if (closes.length < period + 1) return [];
  const out: number[] = new Array(closes.length).fill(NaN);

  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gain += diff;
    else loss -= diff;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;

  const rs0 = avgLoss === 0 ? Infinity : avgGain / avgLoss;
  out[period] = 100 - 100 / (1 + rs0);

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const g = diff > 0 ? diff : 0;
    const l = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;

    const rs = avgLoss === 0 ? Infinity : avgGain / avgLoss;
    out[i] = 100 - 100 / (1 + rs);
  }
  return out;
}

export function stochRsi(closes: number[], rsiPeriod = 14, stochPeriod = 14, smoothK = 3): { k: number[]; d: number[] } {
  const rsis = rsi(closes, rsiPeriod);
  const k: number[] = new Array(closes.length).fill(NaN);
  const d: number[] = new Array(closes.length).fill(NaN);

  for (let i = 0; i < rsis.length; i++) {
    if (!Number.isFinite(rsis[i])) continue;
    const start = Math.max(0, i - stochPeriod + 1);
    const window = rsis.slice(start, i + 1).filter(Number.isFinite);
    if (window.length < stochPeriod) continue;
    const minR = Math.min(...window);
    const maxR = Math.max(...window);
    const denom = maxR - minR;
    const raw = denom === 0 ? 0 : (rsis[i] - minR) / denom; // 0..1
    k[i] = raw;
  }

  // Smooth %K
  const kSmooth: number[] = k.map((_, i) => {
    const start = Math.max(0, i - smoothK + 1);
    const window = k.slice(start, i + 1).filter(Number.isFinite);
    if (window.length < smoothK) return NaN;
    return window.reduce((a, b) => a + b, 0) / window.length;
  });

  // %D as 3-period SMA of smoothed K
  const dSmooth: number[] = kSmooth.map((_, i) => {
    const start = Math.max(0, i - 3 + 1);
    const window = kSmooth.slice(start, i + 1).filter(Number.isFinite);
    if (window.length < 3) return NaN;
    return window.reduce((a, b) => a + b, 0) / window.length;
  });

  return { k: kSmooth, d: dSmooth };
}

export function isStochRsiBullCross(k: number[], d: number[]): boolean {
  const n = k.length;
  if (n < 3) return false;
  const i = n - 1;
  if (!Number.isFinite(k[i]) || !Number.isFinite(d[i]) || !Number.isFinite(k[i - 1]) || !Number.isFinite(d[i - 1])) return false;
  // Bull cross: k crosses above d
  return k[i - 1] <= d[i - 1] && k[i] > d[i];
}
