import axios, { AxiosRequestConfig } from "axios";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";

const API_BASE = "https://api.upbit.com";

export interface UpbitTicker {
  market: string;
  trade_price: number;
  acc_trade_price_24h: number;
  acc_trade_volume_24h: number;
  signed_change_rate?: number;
}

export interface UpbitCandleMinute {
  market: string;
  candle_date_time_kst: string;
  opening_price: number;
  high_price: number;
  low_price: number;
  trade_price: number;
  candle_acc_trade_volume: number;
  candle_acc_trade_price?: number;
}

export interface UpbitAccount {
  currency: string;
  balance: string;
  locked: string;
  avg_buy_price: string;
  unit_currency: string;
}

export interface UpbitOrder {
  uuid: string;
  side: "bid" | "ask";
  ord_type: "limit" | "price" | "market" | "best";
  price: string | null;
  state: "wait" | "watch" | "done" | "cancel";
  market: string;
  created_at: string;
  volume: string | null;
  remaining_volume: string;
  reserved_fee: string;
  remaining_fee: string;
  paid_fee: string;
  locked: string;
  executed_volume: string;
  trades_count: number;
  trades?: Array<{ market: string; price: string; volume: string; funds: string; created_at: string; side: string }>;
}

function buildQueryString(params: Record<string, any>): string {
  const entries = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null)
    .map(([k, v]) => [k, String(v)] as [string, string])
    .sort(([a], [b]) => a.localeCompare(b));
  const usp = new URLSearchParams(entries);
  // URLSearchParams uses percent-encoding; Upbit examples hash urlencoded query string
  return usp.toString();
}

function authHeader(accessKey: string, secretKey: string, params?: Record<string, any>): Record<string, string> {
  const payload: any = {
    access_key: accessKey,
    nonce: uuidv4()
  };
  if (params && Object.keys(params).length > 0) {
    const qs = buildQueryString(params);
    const hash = crypto.createHash("sha512").update(qs).digest("hex");
    payload.query_hash = hash;
    payload.query_hash_alg = "SHA512";
  }
  const token = jwt.sign(payload, secretKey);
  return { Authorization: `Bearer ${token}` };
}

// ------- Public endpoints (no auth) -------
export async function listMarkets(): Promise<Array<{ market: string; korean_name: string; english_name: string }>> {
  const res = await axios.get(`${API_BASE}/v1/market/all`, { params: { isDetails: false } });
  return res.data;
}

export async function getTickers(markets: string[]): Promise<UpbitTicker[]> {
  // Upbit ticker endpoint accepts comma-separated markets; chunk to avoid URL length limits.
  const out: UpbitTicker[] = [];
  const chunkSize = 100;
  for (let i = 0; i < markets.length; i += chunkSize) {
    const chunk = markets.slice(i, i + chunkSize);
    const res = await axios.get(`${API_BASE}/v1/ticker`, { params: { markets: chunk.join(",") } });
    out.push(...res.data);
  }
  return out;
}

export async function getMinuteCandles(unit: 1 | 3 | 5 | 10 | 15 | 30 | 60 | 240, market: string, count: number): Promise<UpbitCandleMinute[]> {
  const res = await axios.get(`${API_BASE}/v1/candles/minutes/${unit}`, { params: { market, count } });
  return res.data;
}

// ------- Private endpoints (JWT auth) -------
export async function getAccounts(accessKey: string, secretKey: string): Promise<UpbitAccount[]> {
  const headers = authHeader(accessKey, secretKey);
  const res = await axios.get(`${API_BASE}/v1/accounts`, { headers });
  return res.data;
}

export async function postOrder(
  accessKey: string,
  secretKey: string,
  body: Record<string, any>
): Promise<UpbitOrder> {
  // POST body must be JSON (Upbit form-urlencoded deprecated). 
  const headers = {
    ...authHeader(accessKey, secretKey, body),
    "Content-Type": "application/json"
  };
  const config: AxiosRequestConfig = { headers };
  const res = await axios.post(`${API_BASE}/v1/orders`, body, config);
  return res.data;
}

export async function getOrder(accessKey: string, secretKey: string, uuid: string): Promise<UpbitOrder> {
  const params = { uuid };
  const headers = authHeader(accessKey, secretKey, params);
  const res = await axios.get(`${API_BASE}/v1/order`, { headers, params });
  return res.data;
}

// helpers
export function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
