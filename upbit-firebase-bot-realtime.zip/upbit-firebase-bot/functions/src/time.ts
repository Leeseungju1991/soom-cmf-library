export const SEOUL_TZ = "Asia/Seoul";

export function seoulDateId(d = new Date()): string {
  // YYYY-MM-DD in Asia/Seoul
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: SEOUL_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
  return fmt.format(d); // en-CA => YYYY-MM-DD
}
