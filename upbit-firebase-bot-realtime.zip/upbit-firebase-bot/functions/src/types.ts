export type BotState = "RUNNING" | "PAUSED" | "ERROR";

export interface GlobalConfig {
  enabled: boolean;
  paperMode: boolean;
  maxOrderKrw: number;          // e.g. 400000
  takeProfitPct: number;        // e.g. 0.03
  stopLossPct: number;          // e.g. -0.06 (negative)
  dailyLossLimitPct: number;    // e.g. 0.30
  cooldownMinutes: number;      // after closing a trade
  candidateCount: number;       // how many markets to evaluate deeply
  prefilterCount: number;       // how many markets to keep by liquidity first
  topMarkets: "KRW";            // currently KRW only
  updatedAt?: any;
  createdAt?: any;
}

export interface RuntimeState {
  botState: BotState;
  pauseReason: string;
  lastRunAt?: any;
  lastError?: string;
}

export interface PositionState {
  isOpen: boolean;
  closing?: boolean;
  closingBy?: string;
  closingAt?: any;
  market?: string;
  entryAt?: any;
  entryPrice?: number;
  qty?: number;
  entryKrw?: number;
  entryFeeKrw?: number;
  tpPrice?: number;
  slPrice?: number;
  lastPrice?: number;
  unrealizedPnlKrw?: number;
  unrealizedPnlPct?: number;
  lastUpdatedAt?: any;
}

export interface SummaryStats {
  initialEquityKrw?: number;
  currentEquityKrw?: number;
  totalRealizedPnlKrw?: number;
  totalFeesKrw?: number;
  totalTrades?: number;
  winTrades?: number;
  lossTrades?: number;
  updatedAt?: any;
}

export interface DailyStats {
  dayStartEquityKrw?: number;
  realizedPnlKrw?: number;
  feesKrw?: number;
  lossLimitTriggered?: boolean;
  lossLimitTriggeredAt?: any;
  updatedAt?: any;
}
