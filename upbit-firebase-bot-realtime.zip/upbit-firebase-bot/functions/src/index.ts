import admin from "firebase-admin";
import { setGlobalOptions } from "firebase-functions/v2";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { onRequest } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";

import { getAccounts, getOrder, getTickers, postOrder, sleep } from "./upbit";
import { pickBestMarketKRW } from "./strategy";
import { SEOUL_TZ, seoulDateId } from "./time";
import { acquireCloseLock, clearPosition, getConfig, getOrInitDaily, getPosition, getSummary, setPosition, setRuntime, setSummary, updateDaily, withLock } from "./store";
import { GlobalConfig } from "./types";

admin.initializeApp();

setGlobalOptions({
  region: "asia-northeast3",   // Seoul
  timeoutSeconds: 180,
  memory: "512MiB"
});

const UPBIT_ACCESS_KEY = defineSecret("UPBIT_ACCESS_KEY");
const UPBIT_SECRET_KEY = defineSecret("UPBIT_SECRET_KEY");
const BOT_INTERNAL_TOKEN = defineSecret("BOT_INTERNAL_TOKEN");

/**
 * Scheduled runner: every minute.
 * - Position exists -> manage TP/SL
 * - No position -> scan & buy
 *
 * Docs: schedule functions use onSchedule and Cloud Scheduler behind the scenes. 
 */
export const tradeRunner = onSchedule(
  {
    schedule: "* * * * *",
    timeZone: SEOUL_TZ,
    secrets: [UPBIT_ACCESS_KEY, UPBIT_SECRET_KEY, BOT_INTERNAL_TOKEN]
  },
  async () => {
    return await withLock(async () => {
      const cfg = await getConfig();
      const accessKey = UPBIT_ACCESS_KEY.value();
      const secretKey = UPBIT_SECRET_KEY.value();

      if (!cfg.enabled) {
        await setRuntime({ botState: "PAUSED", pauseReason: "MANUAL_STOP" });
        return;
      }

      try {
        await setRuntime({ botState: "RUNNING", pauseReason: "" });

        // 1) Refresh equity & daily loss check
        const equity = await computeEquityKrw(accessKey, secretKey);
        await updateSummaryEquity(equity);

        const dayId = seoulDateId();
        const daily = await getOrInitDaily(dayId);
        if (!daily.dayStartEquityKrw) {
          await updateDaily(dayId, { dayStartEquityKrw: equity });
        }

        const dayStart = daily.dayStartEquityKrw ?? equity;
        const lossPct = (equity - dayStart) / dayStart;

        // If daily loss limit triggered, stop + liquidate position
        if (lossPct <= -cfg.dailyLossLimitPct) {
          await handleDailyStop(accessKey, secretKey, cfg, dayId, equity, lossPct);
          return;
        }

        // 2) Position management
        const pos = await getPosition();
        if (pos.isOpen && pos.market && pos.qty && pos.entryPrice && pos.entryKrw !== undefined) {
          await manageOpenPosition(accessKey, secretKey, cfg, dayId, equity);
          return;
        }

        // 3) No position: cooldown check (stored on runtime by lastCloseAt)
        const rtSnap = await admin.firestore().doc("state/runtime").get();
        const rt = rtSnap.data() as any;
        const lastCloseAtMs = rt?.lastCloseAtMs as number | undefined;
        if (lastCloseAtMs) {
          const cdMs = (cfg.cooldownMinutes ?? 5) * 60_000;
          if (Date.now() - lastCloseAtMs < cdMs) {
            return;
          }
        }

        // 4) Scan & buy
        await scanAndBuy(accessKey, secretKey, cfg, equity);
      } catch (e: any) {
        console.error("tradeRunner error:", e?.message || e);
        await setRuntime({ botState: "ERROR", pauseReason: "API_ERROR", lastError: String(e?.message || e) });
      }
    });
  }
);

async function computeEquityKrw(accessKey: string, secretKey: string): Promise<number> {
  const accounts = await getAccounts(accessKey, secretKey);
  const krw = accounts.find(a => a.currency === "KRW");
  const krwBalance = krw ? (parseFloat(krw.balance) + parseFloat(krw.locked)) : 0;

  // Only one position expected; but compute any non-KRW with ticker.
  const non = accounts.filter(a => a.currency !== "KRW" && (parseFloat(a.balance) + parseFloat(a.locked)) > 0);
  if (non.length === 0) return krwBalance;

  const markets = non.map(a => `${a.unit_currency}-${a.currency}`); // e.g. KRW-BTC
  const tickers = await getTickers(markets);
  const priceMap = new Map(tickers.map(t => [t.market, t.trade_price]));

  let assets = 0;
  for (const a of non) {
    const m = `${a.unit_currency}-${a.currency}`;
    const p = priceMap.get(m) ?? 0;
    assets += (parseFloat(a.balance) + parseFloat(a.locked)) * p;
  }
  return krwBalance + assets;
}

async function updateSummaryEquity(equity: number) {
  const summary = await getSummary();
  const initial = summary.initialEquityKrw ?? equity;
  await setSummary({
    initialEquityKrw: initial,
    currentEquityKrw: equity
  });
}

async function handleDailyStop(accessKey: string, secretKey: string, cfg: GlobalConfig, dayId: string, equity: number, lossPct: number) {
  console.warn("Daily loss limit triggered:", lossPct);
  // try liquidate if position exists
  const pos = await getPosition();
  if (pos.isOpen && pos.market && pos.qty) {
    const locked = await acquireCloseLock("daily");
    if (locked) {
      const sellRes = await tryMarketSellAll(accessKey, secretKey, cfg, pos.market, pos.qty);
      if (sellRes) {
        await clearPosition();
      } else {
        await setRuntime({ botState: "ERROR", pauseReason: "SELL_FAILED", lastError: "Daily stop sell failed" });
      }
    }
  }
  // disable bot
  await admin.firestore().doc("config/global").set({ enabled: false, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  await setRuntime({ botState: "PAUSED", pauseReason: "DAILY_LOSS_LIMIT" });
  await updateDaily(dayId, {
    lossLimitTriggered: true,
    lossLimitTriggeredAt: admin.firestore.FieldValue.serverTimestamp()
  });
}

async function manageOpenPosition(accessKey: string, secretKey: string, cfg: GlobalConfig, dayId: string, equity: number) {
  const pos = await getPosition();
  if ((pos as any).closing) return;
  const ticker = (await getTickers([pos.market!]))[0];
  const price = ticker.trade_price;
  const entryPrice = pos.entryPrice!;
  const pnlPct = (price - entryPrice) / entryPrice;
  const pnlKrw = (price - entryPrice) * pos.qty!;

  await setPosition({
    lastPrice: price,
    unrealizedPnlPct: pnlPct,
    unrealizedPnlKrw: pnlKrw
  });

  const tp = cfg.takeProfitPct;
  const sl = cfg.stopLossPct; // negative
  if (pnlPct >= tp) {
    await closePosition(accessKey, secretKey, cfg, dayId, "TAKE_PROFIT");
  } else if (pnlPct <= sl) {
    await closePosition(accessKey, secretKey, cfg, dayId, "STOP_LOSS");
  }
}

async function closePosition(accessKey: string, secretKey: string, cfg: GlobalConfig, dayId: string, reason: "TAKE_PROFIT" | "STOP_LOSS" | "DAILY_STOP" | "MANUAL") {
  const locked = await acquireCloseLock("functions");
  if (!locked) return;
  const pos = await getPosition();
  if (!pos.isOpen || !pos.market || !pos.qty || !pos.entryKrw) return;

  const sellRes = await tryMarketSellAll(accessKey, secretKey, cfg, pos.market, pos.qty);
  if (!sellRes) {
    // could not close -> pause
    await setRuntime({ botState: "ERROR", pauseReason: "SELL_FAILED", lastError: "Market sell failed" });
    await admin.firestore().doc("config/global").set({ enabled: false }, { merge: true });
    await setPosition({ closing: false, closingBy: "", closingAt: null });
    return;
  }

  const { exitKrw, exitFeeKrw, avgExitPrice } = sellRes;
  const entryKrw = pos.entryKrw;
  const entryFee = pos.entryFeeKrw ?? 0;
  const fees = entryFee + exitFeeKrw;
  const pnl = exitKrw - entryKrw - fees;
  const pnlPct = pnl / entryKrw;

  // record trade
  const tradeId = `${Date.now()}_${pos.market.replace("-", "_")}`;
  await admin.firestore().collection("trades").doc(tradeId).set({
    market: pos.market,
    entryAt: pos.entryAt ?? null,
    exitAt: admin.firestore.FieldValue.serverTimestamp(),
    entryPrice: pos.entryPrice,
    exitPrice: avgExitPrice,
    qty: pos.qty,
    entryKrw,
    exitKrw,
    feesKrw: fees,
    pnlKrw: pnl,
    pnlPct,
    exitReason: reason
  });

  // update summary & daily
  const summary = await getSummary();
  const totalRealized = (summary.totalRealizedPnlKrw ?? 0) + pnl;
  const totalFees = (summary.totalFeesKrw ?? 0) + fees;
  const totalTrades = (summary.totalTrades ?? 0) + 1;
  const winTrades = (summary.winTrades ?? 0) + (pnl >= 0 ? 1 : 0);
  const lossTrades = (summary.lossTrades ?? 0) + (pnl < 0 ? 1 : 0);

  await setSummary({
    totalRealizedPnlKrw: totalRealized,
    totalFeesKrw: totalFees,
    totalTrades,
    winTrades,
    lossTrades
  });

  // daily
  const dailyRef = admin.firestore().doc(`stats_daily/${dayId}`);
  const dailySnap = await dailyRef.get();
  const daily = dailySnap.data() as any || {};
  await dailyRef.set({
    realizedPnlKrw: (daily.realizedPnlKrw ?? 0) + pnl,
    feesKrw: (daily.feesKrw ?? 0) + fees,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  // clear position
  await clearPosition();

  // mark cooldown
  await admin.firestore().doc("state/runtime").set({ lastCloseAtMs: Date.now() }, { merge: true });

  // refresh equity once
  const newEquity = await computeEquityKrw(accessKey, secretKey);
  await updateSummaryEquity(newEquity);
}

async function scanAndBuy(accessKey: string, secretKey: string, cfg: GlobalConfig, equity: number) {
  // figure out order size
  const accounts = await getAccounts(accessKey, secretKey);
  const krw = accounts.find(a => a.currency === "KRW");
  const available = krw ? parseFloat(krw.balance) : 0;
  const orderKrw = Math.min(available, cfg.maxOrderKrw);
  if (orderKrw < 5000) {
    await setRuntime({ botState: "PAUSED", pauseReason: "INSUFFICIENT_KRW" });
    return;
  }

  const best = await pickBestMarketKRW({
    prefilterCount: cfg.prefilterCount ?? 30,
    candidateCount: cfg.candidateCount ?? 12,
    distMax: 0.005,
    rsiMax: 30,
    requireStochCross: true,
    minVolRatio: 1.2
  });

  if (!best) return;

  if (cfg.paperMode) {
    // Paper buy: simulate fill at currentPrice
    const qty = orderKrw / best.currentPrice;
    const fee = orderKrw * 0.0005; // rough default; actual fee may differ
    const entryKrw = orderKrw;
    const entryPrice = best.currentPrice;

    await setPosition({
      isOpen: true,
      market: best.market,
      entryAt: admin.firestore.FieldValue.serverTimestamp(),
      entryPrice,
      qty,
      entryKrw,
      entryFeeKrw: fee,
      tpPrice: entryPrice * (1 + cfg.takeProfitPct),
      slPrice: entryPrice * (1 + cfg.stopLossPct)
    });

    console.log("PAPER BUY", best.market, best.reason.join(" | "));
    return;
  }

  // Real buy (market buy): ord_type=price with KRW amount 
  const buy = await postOrder(accessKey, secretKey, {
    market: best.market,
    side: "bid",
    ord_type: "price",
    price: String(Math.floor(orderKrw)) // KRW amount
  });

  // wait until order becomes done (poll a few times)
  const details = await waitOrderDone(accessKey, secretKey, buy.uuid);
  const fill = extractFill(details);
  if (!fill) throw new Error("BUY_FILL_NOT_FOUND");

  const entryPrice = fill.avgPrice;
  const qty = fill.volume;
  const entryKrw = fill.funds;
  const fee = fill.fee;

  await setPosition({
    isOpen: true,
    market: best.market,
    entryAt: admin.firestore.FieldValue.serverTimestamp(),
    entryPrice,
    qty,
    entryKrw,
    entryFeeKrw: fee,
    tpPrice: entryPrice * (1 + cfg.takeProfitPct),
    slPrice: entryPrice * (1 + cfg.stopLossPct)
  });

  console.log("BUY", best.market, best.reason.join(" | "));
}

async function waitOrderDone(accessKey: string, secretKey: string, uuid: string) {
  let last: any = null;
  for (let i = 0; i < 8; i++) {
    last = await getOrder(accessKey, secretKey, uuid);
    if (last.state === "done") return last;
    await sleep(1000);
  }
  return last;
}

function extractFill(order: any): { avgPrice: number; volume: number; funds: number; fee: number } | null {
  const executed = parseFloat(order.executed_volume ?? "0");
  const fee = parseFloat(order.paid_fee ?? "0");
  if (executed <= 0) return null;

  // Prefer trades array to compute exact funds
  let funds = 0;
  if (Array.isArray(order.trades) && order.trades.length > 0) {
    for (const t of order.trades) {
      funds += parseFloat(t.price) * parseFloat(t.volume);
    }
  } else if (order.price) {
    // market buy: order.price is total purchase amount (docs) 
    funds = parseFloat(order.price);
  } else {
    funds = 0;
  }

  const avgPrice = funds > 0 ? funds / executed : NaN;
  if (!Number.isFinite(avgPrice)) return null;
  return { avgPrice, volume: executed, funds, fee };
}

async function tryMarketSellAll(accessKey: string, secretKey: string, cfg: GlobalConfig, market: string, qty: number) {
  if (cfg.paperMode) {
    const ticker = (await getTickers([market]))[0];
    const price = ticker.trade_price;
    const funds = qty * price;
    const fee = funds * 0.0005;
    return { exitKrw: funds, exitFeeKrw: fee, avgExitPrice: price };
  }

  // Market sell: ord_type=market with volume 
  let remaining = qty;
  let totalFunds = 0;
  let totalFee = 0;
  let weightedPx = 0;
  let filledVol = 0;

  for (let attempt = 0; attempt < 3; attempt++) {
    const sell = await postOrder(accessKey, secretKey, {
      market,
      side: "ask",
      ord_type: "market",
      volume: String(remaining)
    });

    const details = await waitOrderDone(accessKey, secretKey, sell.uuid);
    const execVol = parseFloat(details.executed_volume ?? "0");
    const fee = parseFloat(details.paid_fee ?? "0");

    let funds = 0;
    if (Array.isArray(details.trades) && details.trades.length > 0) {
      for (const t of details.trades) {
        funds += parseFloat(t.price) * parseFloat(t.volume);
      }
    } else {
      // fallback: use last price
      const ticker = (await getTickers([market]))[0];
      funds = execVol * ticker.trade_price;
    }

    if (execVol > 0) {
      filledVol += execVol;
      totalFunds += funds;
      totalFee += fee;
      weightedPx += funds; // funds = price*vol; weighted average computed later
      remaining = Math.max(0, remaining - execVol);
    }

    if (details.state === "done" && remaining <= 1e-12) break;
    if (remaining <= 1e-12) break;

    await sleep(800);
  }

  if (filledVol <= 0) return null;
  const avgExitPrice = totalFunds / filledVol;
  return { exitKrw: totalFunds, exitFeeKrw: totalFee, avgExitPrice };
}


/**
 * Realtime close endpoint (called by Cloud Run websocket monitor)
 * - Secured by BOT_INTERNAL_TOKEN secret
 * - Idempotent via position.closing flag
 */
export const closeNow = onRequest(
  {
    region: "asia-northeast3",
    timeoutSeconds: 60,
    memory: "256MiB",
    secrets: [UPBIT_ACCESS_KEY, UPBIT_SECRET_KEY, BOT_INTERNAL_TOKEN]
  },
  async (req, res) => {
    try {
      if (req.method !== "POST") {
        res.status(405).send("METHOD_NOT_ALLOWED");
        return;
      }

      const auth = (req.headers["authorization"] || "").toString();
      const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
      if (!token || token !== BOT_INTERNAL_TOKEN.value()) {
        res.status(401).send("UNAUTHORIZED");
        return;
      }

      const reason = (req.body?.reason || "").toString();
      if (reason !== "TAKE_PROFIT" && reason !== "STOP_LOSS") {
        res.status(400).send("BAD_REASON");
        return;
      }

      const cfg = await getConfig();
      const accessKey = UPBIT_ACCESS_KEY.value();
      const secretKey = UPBIT_SECRET_KEY.value();

      // If bot disabled, ignore (but still allow closing an existing position if any)
      if (!cfg.enabled) {
        // still try to close if there is an open position AND TP/SL triggered
      }

      await closePosition(accessKey, secretKey, cfg, seoulDateId(), reason);
      res.status(200).json({ ok: true });
    } catch (e: any) {
      console.error("closeNow error:", e?.message || e);
      res.status(500).send(String(e?.message || e));
    }
  }
);
