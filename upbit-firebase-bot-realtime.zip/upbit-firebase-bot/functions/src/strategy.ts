import { ema, isStochRsiBullCross, rsi as rsiSeries, stochRsi } from "./indicators";
import { getMinuteCandles, getTickers, listMarkets, UpbitCandleMinute, UpbitTicker } from "./upbit";

export interface CandidateResult {
  market: string;
  score: number;
  reason: string[];
  currentPrice: number;
  low3h: number;
  dist: number;
  rsi: number;
  volRatio: number;
  ema200: number;
  emaSlope: number;
}

function lastFinite(arr: number[]): number | null {
  for (let i = arr.length - 1; i >= 0; i--) if (Number.isFinite(arr[i])) return arr[i];
  return null;
}

function lastTwoFinite(arr: number[]): [number, number] | null {
  let a: number | null = null;
  let b: number | null = null;
  for (let i = arr.length - 1; i >= 0; i--) {
    if (!Number.isFinite(arr[i])) continue;
    if (a === null) a = arr[i];
    else { b = arr[i]; break; }
  }
  if (a === null || b === null) return null;
  return [a, b];
}

function ohlcvToCloses(c: UpbitCandleMinute[]): number[] {
  // Upbit returns newest-first; convert to oldest-first for indicators
  return c.slice().reverse().map(x => x.trade_price);
}

function ohlcvToVolumes(c: UpbitCandleMinute[]): number[] {
  return c.slice().reverse().map(x => x.candle_acc_trade_volume);
}

export async function pickBestMarketKRW(opts: {
  prefilterCount: number;
  candidateCount: number;
  distMax: number;        // e.g. 0.005
  rsiMax: number;         // e.g. 30
  requireStochCross: boolean;
  minVolRatio: number;    // e.g. 1.2
}): Promise<CandidateResult | null> {

  // 1) list markets
  const markets = await listMarkets();
  const krwMarkets = markets.map(m => m.market).filter(m => m.startsWith("KRW-"));

  // 2) liquidity prefilter using 24h trade amount from ticker (fast)
  const tickers = await getTickers(krwMarkets);
  const sortedBy24h = tickers
    .filter(t => Number.isFinite(t.acc_trade_price_24h) && Number.isFinite(t.trade_price))
    .sort((a, b) => b.acc_trade_price_24h - a.acc_trade_price_24h);

  const pre = sortedBy24h.slice(0, Math.max(5, opts.prefilterCount));
  const candidates = pre.slice(0, Math.max(5, opts.candidateCount));

  // 3) Deep-evaluate candidates
  const results: CandidateResult[] = [];
  for (const t of candidates) {
    const r = await evaluateMarket(t.market, t.trade_price, opts);
    if (r) results.push(r);
  }

  if (results.length === 0) return null;
  results.sort((a, b) => b.score - a.score);
  return results[0];
}

async function evaluateMarket(market: string, currentPrice: number, opts: any): Promise<CandidateResult | null> {
  const reasons: string[] = [];

  // --- 3h low using 1m candles (need 180)
  const c1m = await getMinuteCandles(1, market, 180);
  if (c1m.length < 60) return null; // too illiquid / sparse candles
  const lows = c1m.map(x => x.low_price);
  const low3h = Math.min(...lows);
  const dist = (currentPrice - low3h) / low3h;
  if (dist > opts.distMax) return null;
  reasons.push(`3h-low-dist=${(dist*100).toFixed(2)}%`);

  // --- RSI(14)
  const closes1m = ohlcvToCloses(c1m);
  const rsiArr = rsiSeries(closes1m, 14);
  const rsi = lastFinite(rsiArr);
  if (rsi === null) return null;
  if (rsi > opts.rsiMax) return null;
  reasons.push(`RSI=${rsi.toFixed(1)}`);

  // --- Stoch RSI bull cross (optional)
  const { k, d } = stochRsi(closes1m, 14, 14, 3);
  const cross = isStochRsiBullCross(k, d);
  if (opts.requireStochCross && !cross) return null;
  reasons.push(cross ? "StochRSI bull cross" : "StochRSI no-cross");

  // --- volume confirmation: last volume vs avg of prev 20
  const vols = ohlcvToVolumes(c1m);
  const lastVol = vols[vols.length - 1];
  const prev = vols.slice(Math.max(0, vols.length - 21), vols.length - 1);
  const avgPrev = prev.reduce((a, b) => a + b, 0) / Math.max(1, prev.length);
  const volRatio = avgPrev > 0 ? lastVol / avgPrev : 0;
  if (volRatio < opts.minVolRatio) return null;
  reasons.push(`VolRatio=${volRatio.toFixed(2)}`);

  // --- Trend filter: 60m EMA200 and slope not down
  const c60 = await getMinuteCandles(60, market, 220);
  if (c60.length < 210) return null;
  const closes60 = ohlcvToCloses(c60);
  const emaArr = ema(closes60, 200);
  const last2 = lastTwoFinite(emaArr);
  if (!last2) return null;
  const [emaNow, emaPrev] = last2;
  const emaSlope = emaNow - emaPrev;
  if (currentPrice < emaNow) return null;
  if (emaSlope < 0) return null;
  reasons.push(`Price>EMA200, slope=${emaSlope.toFixed(2)}`);

  // Score: tighter dist + lower RSI + higher volRatio + positive slope
  const score =
    (1 - Math.min(dist / opts.distMax, 1)) * 40 +
    (1 - Math.min(rsi / opts.rsiMax, 1)) * 30 +
    Math.min(volRatio / (opts.minVolRatio * 2), 2) * 20 +
    Math.min(Math.max(emaSlope, 0) / (emaNow * 0.0001), 2) * 10 +
    (cross ? 5 : 0);

  return {
    market,
    score,
    reason: reasons,
    currentPrice,
    low3h,
    dist,
    rsi,
    volRatio,
    ema200: emaNow,
    emaSlope
  };
}
